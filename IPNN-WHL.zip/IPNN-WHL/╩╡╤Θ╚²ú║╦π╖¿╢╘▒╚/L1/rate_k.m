%%%%%%%%%%    ��Candes-L1���㷨����100�γɹ���-ϡ���ʵ��    %%%%%%%%%%%
%% ��ʼ��
path(path, './Optimization');
path(path, './Data');
%% ��������
T = 100;
k_set = (1:70);
snr = zeros(T,length(k_set));
re = zeros(T,length(k_set));
rate = zeros(1,length(k_set));
%% ��������
for t = 1:T
    for j = 1:length(k_set)
        m = 64;
        n = 128;
        k = k_set(j);
        x_original = zeros(n,1);
        s = randperm(n);
        x_original(s(1:k)) = randn(k,1);
        A = randn(m,n);
        A = orth(A')';
        y = awgn(A*x_original,30);
        x0 = A'*y;
        
        x_recovered = l1eq_pd(x0, A, [], y, 1e-3);
        
        re(t,j) = norm(x_recovered-x_original,2)^2./norm(x_original,2)^2;
        snr(t,j) = 10*log10(re(t,j));
        if re(t,j)<1e-3
           rate(j) = rate(j)+1;
        end
    end
end

for t = 1:T
    for j = 1:length(k_set)
        if re(t,j)<0.05
           rate(j) = rate(j)+1;
        end
    end
end




