%%%%%%%%%%    ��Candes-L1���㷨���Գ���    %%%%%%%%%%%
%% ��ʼ��
clear all
close all
clc
rand('state', 2019)
randn('state', 2019)

path(path, './Optimization');
path(path, './Data');

%% ��������
dB_set = [1,5,10,15,20,25,30,35,40];
snr = zeros(1,length(dB_set));
re = zeros(1,length(dB_set));
for j = 1:length(dB_set)
    
    dB = dB_set(j);
    m = 64;
    n = 128;
    k = 10;

    x_original = zeros(n,1);
    q = randperm(n);
    x_original(q(1:k)) = randn(k,1);

    disp('Creating measurment matrix...');
    A = randn(m,n);
    A = orth(A')';
    disp('Done.');
	
    y = awgn(A*x_original,dB);

    x0 = A'*y;

    tic
    xp = l1eq_pd(x0, A, [], y, 1e-3);
    toc

    x_recovered = xp;
    re(j) = norm(x_recovered-x_original,2)^2./norm(x_original,2)^2;
    snr(j) = 10*log10(re(j));
end



