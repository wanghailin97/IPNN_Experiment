%%%%%%%%%%    ��Candes-L1���㷨����100�����-����ʵ��    %%%%%%%%%%%
%% ��ʼ��

path(path, './Optimization');
path(path, './Data');
%% ��������
T = 100;
dB_set = [1,2,3,4,5,10,15,20,30,40];
snr = zeros(T,length(dB_set));
re = zeros(T,length(dB_set));
%% ����ʵ��
for t = 1:T
    for j = 1:length(dB_set)
        m = 64;
        n = 128;
        k = 10;
        x_original = zeros(n,1);
        s = randperm(n);
        x_original(s(1:k)) = randn(k,1);
        A = randn(m,n);
        A = orth(A')';
        
        dB = dB_set(j);
        y = awgn(A*x_original,dB);
        x0 = A'*y;
        x_recovered = l1eq_pd(x0, A, [], y, 1e-3);
        
        re(t,j) = norm(x_recovered-x_original,2)^2./norm(x_original,2)^2;
        snr(t,j) = 10*log10(re(t,j));
    end
end





