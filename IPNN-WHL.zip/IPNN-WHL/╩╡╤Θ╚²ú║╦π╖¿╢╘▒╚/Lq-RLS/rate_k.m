%%%%%%%%%%    ��Lq_RLS���㷨����100�γɹ���-ϡ���ʵ��    %%%%%%%%%%%
%% ��������
T = 100;
k_set = (1:70);
snr = zeros(T,length(k_set));
re = zeros(T,length(k_set));
rate = zeros(1,length(k_set));
%% ��������
for t = 1:T
    for j = 1:length(k_set)
       %% ģ�Ͳ�������
        m = 128;                          
        n = 512;                         
        k = k_set(j);                          
        A = randn(m,n);                   
        x_original = zeros(n,1);
        s =randperm(n);
        x_original(s(1:k)) = randn(k,1); 
        y = A*x_original;                

        %% �㷨��������
        opts.x0 = zeros(n,1);    % initialazed iteration vector
        opts.s0_2q = k;          % estimated block sparsity
        opts.eps0 = 1;           % initialazed smoothing parameter
        opts.maxit = 100;        % maximum iteration steps
        opts.tol = 1e-5;         % parameter
        opts.alpha = 0.9;        % step size
        opts.lambda = 1e-7;      % regularization parameter
        q =0.5;                  % q norm
        %% �㷨������
        x_recovered = Lp_IRLS(A,y,q,opts);
        re(t,j) = norm(x_recovered-x_original,2)^2./norm(x_original,2)^2;
        snr(t,j) = 10*log10(re(t,j));
        if re(t,j)<1e-3
           rate(j) = rate(j)+1;
        end
    end
end 
    