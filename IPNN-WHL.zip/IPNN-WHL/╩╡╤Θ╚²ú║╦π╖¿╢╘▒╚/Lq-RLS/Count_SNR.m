%%%%%%%%%%    （Lq_RLS）算法运行100次成功率-噪音实验    %%%%%%%%%%%
%% 参数设置
T = 100;
dB_set = [1,5,10,15,20,25,30,35,40];
snr = zeros(T,length(dB_set));
re = zeros(T,length(dB_set));
count = zeros(1,length(dB_set));
%% 迭代过程
for t = 1:T
    for j = 1:length(k_set)
       %% 模型参数设置
	    dB = dB_set(j);
        m = 64;                          
        n = 128;                         
        k = 10;                          
        A = randn(m,n);                   
        x_original = zeros(n,1);
        s =randperm(n);
        x_original(s(1:k)) = randn(k,1); 
        y = awgn(A*x_original,dB);                

        %% 算法参数设置
        opts.x0 = zeros(n,1);    % initialazed iteration vector
        opts.s0_2q = k;          % estimated block sparsity
        opts.eps0 = 1;           % initialazed smoothing parameter
        opts.maxit = 100;        % maximum iteration steps
        opts.tol = 1e-5;         % parameter
        opts.alpha = 0.9;        % step size
        opts.lambda = 1e-7;      % regularization parameter
        q = 1;                  % q norm
        %% 算法求解过程
        x_recovered = Lp_IRLS(A,y,q,opts);
        re(t,j) = norm(x_recovered-x_original,2)^2./norm(x_original,2)^2;
        snr(t,j) = 10*log10(re(t,j));
        if re(t,j)<1e-3
           count(j) = count(j)+1;
        end
    end
end 
    