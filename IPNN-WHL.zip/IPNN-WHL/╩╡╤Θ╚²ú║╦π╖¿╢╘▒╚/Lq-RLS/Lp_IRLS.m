function x = Lp_IRLS(A,b,q,opts)
% Lq method to recovery sparse vectors
         
%%%%%%%%%%%%%%%%%%%%%%%%Input:%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%          A: measurement matrix
%          b: measurement vector
%          q: norm
%    opts.x0: initialazed iteration vector
% opts.s0_2q: estimated block sparsity
%  opts.eps0: initialazed smoothing parameter
% opts.maxit: maximum iteration steps
%   opts.tol: parameter
% opts.alpha: step size
%opts.lambda: regularization parameter

%%%%%%%%%%%%%%%%%%%%%%Output:%%%%%%%%%%%%%%%%%%%%%%%%%%

%          x: recovery vector
%   Out.iter: final iteration number
%Out.CPUtime: total time to recover the vector


[m,n] = size(A); 
x = zeros(n,1);
s = round(m/2);  
eps = 1; 
MaxIter = 500; 
alpha = 0.9;
lambda = 1e-7;
tol = 1e-5;

if isfield(opts,'x0')       x = opts.x0;                 end
if isfield(opts,'s0_q')     s = opts.s0_q;               end
if isfield(opts,'eps0')     eps = opts.eps0;             end
if isfield(opts,'maxit')    MaxIter = opts.maxit;        end
if isfield(opts,'alpha')    alpha = opts.alpha;          end
if isfield(opts,'lambda')   lambda = opts.lambda;        end
if isfield(opts,'tol')      tol = opts.tol;              end



em = ones(1,m);
lamq = lambda*q; p = 1-q/2;
At = A'; Atb = At*b; 
I = speye(m);
linopt.SYM = true; 
linopt.POSDEF = true;
min_iter = 10; 
ds = 1;
nstall = 0; 
%denote the (s+1)th largest component
tic
for  iter=1:MaxIter
    
    %solve reweighted equation
    w = eps^2+x.^2; w = w.^p/lamq;
    wAtb = w.*Atb;
    wAt = (w*em).*At;
    w = linsolve(I+A*wAt, A*wAtb, linopt);
    x = wAtb-wAt*w;
    
    %get the (s+1)th largest component
    y = sort(abs(x),'descend');
    ds0 = ds;  
    ds = y(s+1);
    
    %decrease smoothing parameter eps
    if iter<min_iter
        eps = min(eps,0.9*y(s+1));
    else eps = min(eps,alpha*y(s+1));
    end

    crit1 = ds<tol;
    crit2 = abs(ds-ds0)<tol*max(1,ds0);  
    
    if crit2 nstall = nstall+1; 
    else
        nstall = 0; 
    end
    
    if crit1 || nstall>=3 
        break;       
    end
     
end
t=toc;
Out.CPUtime = t;
Out.iter = iter;

end